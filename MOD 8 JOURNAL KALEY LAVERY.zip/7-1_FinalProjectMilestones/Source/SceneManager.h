///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////
#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>
#include <cstdint>   // for uint32_t

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
    // constructor / destructor
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    // properties for loaded texture access
    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    // properties for object materials (not required for textures-only work,
    // but kept for completeness / future milestones)
    struct OBJECT_MATERIAL
    {
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

private:
    // pointers to managers / meshes
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_basicMeshes;

    // textures
    int            m_loadedTextures;
    TEXTURE_INFO   m_textureIDs[16];

    // materials
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // texture helpers
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();
    int  FindTextureID(std::string tag);
    int  FindTextureSlot(std::string tag);
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // transforms & shader setters
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

    void SetShaderTexture(std::string textureTag);
    void SetTextureUVScale(float u, float v);
    void SetShaderMaterial(std::string materialTag);

public:
    // *** Students customize these ***
    void LoadSceneTextures();   // <? MISSING BEFORE (now added)
    void PrepareScene();
    void RenderScene();
};
