///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////
#pragma once

#include "ShaderManager.h"
#include "Camera.h"
#include <GLFW/glfw3.h>

class ViewManager
{
public:
	ViewManager(ShaderManager* pShaderManager);
	~ViewManager();

	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	void PrepareSceneView();
	void ProcessKeyboardEvents();

	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
	ShaderManager* m_pShaderManager;
	GLFWwindow* m_pWindow;
};





